$(document).ready(function() {
  $('.close a').click(function(e){
    e.preventDefault();
    $('.message').remove();
  });
});